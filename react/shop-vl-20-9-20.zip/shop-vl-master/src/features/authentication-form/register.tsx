import React, { useContext, useState, useCallback } from 'react';
import Link from 'next/link';
import { Input } from 'components/forms/input';
import {
  Button,
  IconWrapper,
  Wrapper,
  Container,
  LogoWrapper,
  Heading,
  SubHeading,
  HelperText,
  Offer,
  // Input,
  Divider,
  LinkButton,
} from './authentication-form.style';
import { Facebook } from 'assets/icons/Facebook';
import { Google } from 'assets/icons/Google';
import { AuthContext } from 'contexts/auth/auth.context';
import { FormattedMessage, useIntl } from 'react-intl';
import axios from 'utils/api/axios';

export default function SignOutModal() {
  const intl = useIntl();
  const { authDispatch } = useContext<any>(AuthContext);
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordReType, setPasswordReType] = useState('');

  const toggleSignInForm = () => {
    authDispatch({
      type: 'SIGNIN',
    });
  };

  const onClickRegister = useCallback(async () => {
    const res = await axios.post('/auth/register', { email, password, fullname: fullName });
    toggleSignInForm()
  }, []);

  const onChangeEmail = useCallback((event) => {
    setEmail(event.target.value);
  }, []);

  const onChangeFullName = useCallback((event) => {
    setFullName(event.target.value);
  }, []);

  const onChangePassword = useCallback((event) => {
    setPassword(event.target.value);
  }, []);

  const onChangePasswordReType = useCallback((event) => {
    setPasswordReType(event.target.value);
  }, []);

  return (
    <Wrapper>
      <Container>
        <Heading>
          <FormattedMessage id='signUpBtnText' defaultMessage='Sign Up' />
        </Heading>
        <SubHeading>
          <FormattedMessage
            id='signUpText'
            defaultMessage='Every fill is required in sign up'
          />
        </SubHeading>
        <Input
          type='text'
          placeholder={intl.formatMessage({
            id: 'userNamePlaceholder',
            defaultMessage: 'User name',
          })}
          height='48px'
          backgroundColor='#F7F7F7'
          mb='10px'
          value={fullName}
          onChange={onChangeFullName}
        />
        <Input
          type='text'
          placeholder={intl.formatMessage({
            id: 'emailAddress-Placeholder',
            defaultMessage: 'Email Address',
          })}
          height='48px'
          backgroundColor='#F7F7F7'
          mb='10px'
          value={email}
          onChange={onChangeEmail}
        />
        <Input
          type='password'
          placeholder={intl.formatMessage({
            id: 'password-Placeholder',
            defaultMessage: 'Password (min 6 characters)',
          })}
          height='48px'
          backgroundColor='#F7F7F7'
          mb='10px'
          value={password}
          onChange={onChangePassword}
        />
        <HelperText style={{ padding: '20px 0 30px' }}>
          <FormattedMessage
            id='signUpText'
            defaultMessage="By signing up, you agree to Pickbazar's"
          />
          &nbsp;
          <Link href='/'>
            <a>
              <FormattedMessage
                id='termsConditionText'
                defaultMessage='Terms &amp; Condition'
              />
            </a>
          </Link>
        </HelperText>
        <Button onClick={onClickRegister} variant='primary' size='big' width='100%' type='submit'>
          <FormattedMessage id='continueBtn' defaultMessage='Continue' />
        </Button>
        {/* <Divider>
          <span>
            <FormattedMessage id='orText' defaultMessage='or' />
          </span>
        </Divider>
        <Button
          variant='primary'
          size='big'
          style={{
            width: '100%',
            backgroundColor: '#4267b2',
            marginBottom: 10,
          }}
        >
          <IconWrapper>
            <Facebook />
          </IconWrapper>
          <FormattedMessage
            id='continueFacebookBtn'
            defaultMessage='Continue with Facebook'
          />
        </Button>
        <Button
          variant='primary'
          size='big'
          style={{ width: '100%', backgroundColor: '#4285f4' }}
        >
          <IconWrapper>
            <Google />
          </IconWrapper>
          <FormattedMessage
            id='continueGoogleBtn'
            defaultMessage='Continue with Google'
          />
        </Button> */}
        <Offer style={{ padding: '20px 0' }}>
          <FormattedMessage
            id='alreadyHaveAccount'
            defaultMessage='Already have an account?'
          />{' '}
          <LinkButton onClick={toggleSignInForm}>
            <FormattedMessage id='loginBtnText' defaultMessage='Login' />
          </LinkButton>
        </Offer>
      </Container>
    </Wrapper>
  );
}
