import { useSWRInfinite } from 'swr';
import Fuse from 'fuse.js';
import { useState } from 'react';
import axios from 'utils/api/axios';
const defaultParam = '&filter[active]=true&filter[pending]=false&sort[createdAt]=-1';
const PAGE_SIZE = 10;

const options = {
  // isCaseSensitive: false,
  // includeScore: false,
  shouldSort: true,
  // includeMatches: false,
  // findAllMatches: false,
  // minMatchCharLength: 1,
  // location: 0,
  threshold: 0.3,
  // distance: 100,
  // useExtendedSearch: false,
  // ignoreLocation: false,
  // ignoreFieldNorm: false,
  minMatchCharLength: 2,
  keys: ['name'],
};
function search(list, pattern) {
  const fuse = new Fuse(list, options);

  return fuse.search(pattern).map((current) => current.item);
}
// import productFetcher from 'utils/api/product';
const productFetcher = (url, page) => axios.get(url + defaultParam).then((res) => res.data);
interface Props {
  type: string;
  text?: any;
  category?: any;
  offset?: number;
  limit?: number;
}
export default function useProducts(variables: Props) {
  const { type, text, category, offset = 0, limit = 20 } = variables ?? {};
  const { data, mutate, error, size, setSize, isValidating } = useSWRInfinite(
    page => text ? `/public/product?page=${page + 1}&filter[product_group]=${category}&filter[name][$regex]=${text}`
      : `/public/product?page=${page + 1}&filter[product_group]=${category}`
    , productFetcher);
  // console.log(data)
  const products = data ? [].concat(...data) : [];
  const docsProducts = []
  for (let index = 0; index < products.length; index++) {
    const { data: { docs } } = products[index];
    docsProducts.push(...docs)
  }
  const isLoadingInitialData = !data && !error;
  const isLoadingMore =
    isLoadingInitialData ||
    (size > 0 && data && typeof data[size - 1] === "undefined");
  const isEmpty = data?.[data.length - 1]?.data?.docs?.length === 0;
  const { page, totalPages } = data?.[data.length - 1]?.data ?? {};
  const isReachingEnd = isEmpty || page >= totalPages;
  // isEmpty || (data && data[data.length - 1]?.length < PAGE_SIZE);
  const isRefreshing = isValidating && data && data.length === size;
  return {
    loading: isLoadingMore,
    error,
    data: docsProducts,
    hasMore: !isLoadingMore && !isReachingEnd,
    mutate,
    fetchMore: () => setSize(size + 1),
  };
}
