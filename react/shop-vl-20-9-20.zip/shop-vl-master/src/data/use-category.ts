import useSWR from 'swr';
import axios from 'utils/api/axios';

// import productFetcher from 'utils/api/product';
const fetcher = (url) => axios.get(url).then((res) => res.data);
interface CategoryProps {
  type: string;
}
export default function useCategory({ type }: CategoryProps) {
  const { data, mutate, error } = useSWR('/public/product-group', fetcher);

  const loading = !data && !error;
  // const categories = data?.docs?.filter((current) => current.type === type);
  const categories = data?.data?.docs;
  // const paginatedData = data?.slice(offset, limit);
  // const loggedOut = error && error.status === 403;

  return {
    loading,
    error,
    data: categories,
    // loggedOut,
    // user: data,
    mutate,
  };
}
