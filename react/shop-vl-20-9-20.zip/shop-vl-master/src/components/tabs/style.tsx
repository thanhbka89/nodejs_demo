import styled from 'styled-components';
import { themeGet } from '@styled-system/theme-get';

const TabsWrapper = styled.div`
.list-order{
    ul {
      padding-left: 0px;
      list-style: none;
    }
  }
  li {
    list-style-type: none;
  }
  .list-order-tabs {
    padding-left: 0px;
    border-bottom: 1px solid rgb(224, 224, 224);
    margin-bottom: 0px;
    &.bg-violet{
      background: #7C57DA;
      li{
        color: #CBBAF6;
        &.active {
          color: #ffffff;
          &::before {
            width: 100%;
            height: 4px;
            position: absolute;
            bottom: 0px;
            left: 0px;
            background: #ffffff;
            content: "";
          }
        }
      }
    }
    li {
      display: inline-block;
      width: calc(50% - 2px);
      text-align: center;
      padding: 15px 10px;
      font-weight: 500;
      color: rgba(0, 0, 0, 0.54);
      font-size: 0.875rem;
      position: relative;
      font-size: 14px;
      &.active {
        color: rgb(27, 168, 255);
        &::before {
          width: 100%;
          height: 4px;
          position: absolute;
          bottom: 0px;
          left: 0px;
          background: rgb(27, 168, 255);
          content: "";
        }
      }
    }
  }
  
  .list-order__item {
    padding: 16px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    border-bottom: 1px solid rgb(224, 224, 224);
    -webkit-box-pack: justify;
    justify-content: space-between;
  }
  .list-order__item__description {
    color: rgb(51, 51, 51);
    font-size: 16px;
    font-weight: 400;
    line-height: 24px;
    margin-bottom: 8px;
  }
  .list-order__item__content {
    color: rgb(117, 117, 117);
  }
  @media (min-width: 768px) {
    .list-order-tabs {
      li {
        font-size: 16px;
      }
    }
  }
`;

export default TabsWrapper;
