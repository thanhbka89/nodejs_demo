import React, { useState, useEffect } from 'react'
import Link from "next/link";
import PropTypes from 'prop-types'
import { useRouter } from "next/router";

import TabsWrapper from './style';

type Props = {
	className?: string;
};

const Content: React.FC<Props> = (props) => {
	const [tabActive, updateTabActive] = useState(1);
	const router = useRouter();

	useEffect(() => {
		updateTabActive(router.pathname === '/invite-friend' ? 1 : 2)
	}, [router.pathname])

	return (
		<TabsWrapper>
			<ul className="list-order-tabs bg-violet">
				<Link href="/invite-friend">
					<li className={tabActive === 1 ? "active" : ''} data-href="#tab1">Mời bạn</li>
				</Link>
				<Link href="/invite-friend/need-handle">
					<li className={tabActive === 2 ? "active" : ''} data-href="#tab2">Cần xử lý</li>
				</Link>
			</ul>
		</TabsWrapper >
	)
}

Content.propTypes = {

}

export default Content

