import React, { useState, useEffect } from "react";
import { NextPage } from "next";
import Link from "next/link";
import useSWR from "swr";
import { format } from "date-fns";
import InfiniteScroll from "react-infinite-scroll-component";
import { SEO } from "components/seo";
import ErrorMessage from "components/error-message/error-message";
import Order from "features/user-profile/order/order";
import {
  PageWrapper,
  SidebarSection,
} from "features/user-profile/user-profile.style";
import Sidebar from "features/user-profile/sidebar/sidebar";
import { Modal } from "@redq/reuse-modal";
import styled from "styled-components";

import HeaderV2 from "layouts/HeaderV2";
import FooterV2 from "layouts/FooterV2";
import ContentV2 from "layouts/ContentV2";

import axios from "utils/api/axios";

const fetcher = (url) => axios.get(url).then((res) => res.data);

const OrderPageWrapper = styled.div`
.Reward__item {
  padding: 7px 16px;
  border-bottom: 1px solid rgb(242, 242, 242);
  font-size: 16px;
  position: relative;
  color: rgb(51, 51, 51);
  background: rgb(255, 255, 255);
  p {
    margin: 10px 0px;
  }
  .Reward__item__number {
    color: rgb(38, 188, 78);
    font-size: 16px;
    &.number--am {
      color: #f90f25;
    }
  }
  .Reward__item__date {
    color: rgb(120, 120, 120);
    font-size: 11px;
  }
  .Reward__item__content {
    font-size: 13px;
    line-height: 18px;
  }
}
`;

const LIMIT = 20;

const OrderPage: NextPage = () => {
  const [state, updateState] = useState({
    notifications: [],
    total: 0,
    page: 0,
    loading: false,
    errorMessage: "",
  });

  const fetchMoreData = async () => {
    try {
      updateState({ ...state, loading: true });
      const { success, data } = await fetcher(
        `/noti/find?limit=${LIMIT}&page=${state.page + 1
        }`
      );
      const { totalDocs, docs } = data;
      updateState({
        ...state,
        total: totalDocs,
        notifications: [...state.notifications, ...docs],
        page: state.page + 1,
        loading: false,
      });
    } catch (error) {
      updateState({ ...state, loading: false, errorMessage: error.message });
    }
  };

  useEffect(() => {
    fetchMoreData();
  }, []);

  return (
    <>
      <SEO title="Order - PickBazar" description="Order Details" />
      <HeaderV2 title="Thông báo" />
      <ContentV2>
        <OrderPageWrapper>
          <div className="Reward-coin">
            <div className="Reward__content">
              <ul>
                <div
                  className="infinite-scroll-component"
                  style={{ height: "auto", overflow: "auto" }}
                >
                  <InfiniteScroll
                    dataLength={state.notifications.length}
                    next={fetchMoreData}
                    hasMore={state.total > state.notifications.length}
                    loader={<h4>Loading...</h4>}
                  >
                    {state.notifications.map(({ title, content, createdAt }) => (
                      <li className="Reward__item">
                        <p className="Reward__item__number">
                          <span>{title}</span>
                        </p>
                        <p className="Reward__item__content" dangerouslySetInnerHTML={{ __html: content }}></p>
                        <p className="Reward__item__date">
                          {format(new Date(createdAt), "dd/MM/yyyy")}
                        </p>
                      </li>
                    ))}
                  </InfiniteScroll>
                  {state.loading && <div>loading...</div>}
                  {state.errorMessage && (
                    <ErrorMessage message={state.errorMessage} />
                  )}
                </div>
              </ul>
            </div>
          </div>
        </OrderPageWrapper>
      </ContentV2>
      <FooterV2 />
      {/* <Modal>
        <PageWrapper>
          <SidebarSection>
            <Sidebar />
          </SidebarSection>
          <Order />
        </PageWrapper>
      </Modal> */}
    </>
  );
};

export default OrderPage;
