import { NextPage } from "next";
import Link from "next/link";
import { format } from "date-fns";
import { Modal } from "@redq/reuse-modal";
import { ProfileProvider } from "contexts/profile/profile.provider";
import SettingsContent from "features/user-profile/settings/settings";
import {
  PageWrapper,
  SidebarSection,
  ContentBox,
} from "features/user-profile/user-profile.style";
import Sidebar from "features/user-profile/sidebar/sidebar";
import { SEO } from "components/seo";
import Footer from "layouts/footer";
import HeaderV2 from "layouts/HeaderV2";
import FooterV2 from "layouts/FooterV2";
import ContentV2 from "layouts/ContentV2";
import ErrorMessage from "components/error-message/error-message";
import useUser from "data/use-user";
import styled from "styled-components";

type Props = {
  deviceType?: {
    mobile: boolean;
    tablet: boolean;
    desktop: boolean;
  };
};

const ShortcutWrapper = styled.div`
  .group {
    margin: 0px 0px 8px;
  }
  .link {
    padding: 10px 16px;
    color: rgb(51, 51, 51);
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    text-decoration: none;
    margin: 0px 0px 1px;
    background-color: rgb(255, 255, 255);
    &.avatar {
      padding: 16px;
    }
    > img {
      margin: 0px 10px 0px 0px;
    }
    > .link__content {
      font-size: 13px;
      line-height: 22px;
      flex: 1 1 auto;
    }
    > .link__icon {
      color: rgb(168, 168, 168);
      margin: 0px 10px 0px 0px;
    }
    > .link__arrow {
      color: rgb(168, 168, 168);
    }
  }
  .link__thumb {
    margin: 0px 16px 0px 0px;
    width: 40px;
    height: 40px;
    border-radius: 50%;
  }
`;

const ProfileWrapper = styled.div`
h1, h2, h3, h4, h5, h6, a, p, span, input, button, select, label, textarea, text, img, ul, li, i, :before, :after, div {
  margin: 0;
  padding: 0;
  outline: none;
  color: inherit;
  text-decoration: none;
}
* {
  margin: 0;
  padding: 0;
  webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
  -webkit-tap-highlight-color: rgba(255, 255, 255, 0);
}
::before, ::after {
  box - sizing: border-box;
}
html, body{
  font - family: Roboto, Helvetica, Arial, sans-serif;
  font-size: 14px;
  background-color: #ffffff;
}
.fix-container {
  margin: 0 auto;
  max-width: 100%;
  position: relative;
}
.main-content{
          min - height: calc(100vh - 56px);
  background: #efefef;
  background-color: #efefef;
  padding-bottom: 56px;
  padding-top: 56px;
}
@media (min-width: 768px) {
  .fix-container{
    width: 768px;
  }
  .main-content{
    min - height: calc(100vh - 56px);
    max-width: 768px;
    margin: auto;
    background-color: rgb(239, 239, 239);
    border-left: 1px solid #efefef;
    border-right: 1px solid #efefef;
  }
}
`;

const ProfilePage: NextPage<Props> = ({ deviceType }) => {
  const { user, error } = useUser();
  if (error) return <ErrorMessage message={error.message} />;
  if (!user) return <div>loading...</div>;

  return (
    <>
      <SEO title="Profile - PickBazar" description="Profile Details" />
      <ProfileProvider initData={user}>
        <ProfileWrapper>
          <HeaderV2 title="Quản lý tài khoản" />
          <ContentV2>
            <ShortcutWrapper>
              <div className="group">
                <a className="link avatar" href="/customer/account/edit">
                  <img
                    className="link__thumb"
                    src="https://graph.facebook.com/783406865190273/picture?width=60&amp;height=60"
                    alt="avatar"
                  />
                  <div className="link__content">
                    <div className="link__name">{user.fullname}</div>
                    <div className="link__email">{user.email}</div>
                    <div className="link__created-date">
                      <span>
                        Thành viên từ:{" "}
                        {user.createdAt &&
                          format(new Date(user.createdAt), "dd/MM/yyyy")}
                      </span>
                    </div>
                  </div>
                  <svg
                    stroke="currentColor"
                    fill="currentColor"
                    strokeWidth="0"
                    viewBox="0 0 512 512"
                    className="link__arrow"
                    size={20}
                    height="20"
                    width="20"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M294.1 256L167 129c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.3 34 0L345 239c9.1 9.1 9.3 23.7.7 33.1L201.1 417c-4.7 4.7-10.9 7-17 7s-12.3-2.3-17-7c-9.4-9.4-9.4-24.6 0-33.9l127-127.1z"></path>
                  </svg>
                </a>
              </div>
              <div className="group">
                <a className="link" href="">
                  <img className="link__icon" src="images/share.svg" />
                  <div className="link__content">Kết nối mạng xã hội</div>
                  <svg
                    stroke="currentColor"
                    fill="currentColor"
                    strokeWidth="0"
                    viewBox="0 0 512 512"
                    className="link__arrow"
                    size={20}
                    height="20"
                    width="20"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M294.1 256L167 129c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.3 34 0L345 239c9.1 9.1 9.3 23.7.7 33.1L201.1 417c-4.7 4.7-10.9 7-17 7s-12.3-2.3-17-7c-9.4-9.4-9.4-24.6 0-33.9l127-127.1z"></path>
                  </svg>
                </a>
                <Link href="/order">
                  <a className="link" href="">
                    <img className="link__icon" src="images/document.svg" />
                    <div className="link__content">Quản lý đơn hàng</div>
                    <svg
                      stroke="currentColor"
                      fill="currentColor"
                      strokeWidth="0"
                      viewBox="0 0 512 512"
                      className="link__arrow"
                      size={20}
                      height="20"
                      width="20"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path d="M294.1 256L167 129c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.3 34 0L345 239c9.1 9.1 9.3 23.7.7 33.1L201.1 417c-4.7 4.7-10.9 7-17 7s-12.3-2.3-17-7c-9.4-9.4-9.4-24.6 0-33.9l127-127.1z"></path>
                    </svg>
                  </a>
                </Link>

              </div>
              <div className="group">
                <Link href="/coin">
                  <a className="link" href="">
                    <img className="link__icon" src="images/document.svg" />
                    <div className="link__content">Quản lý điểm thưởng</div>
                    <svg
                      stroke="currentColor"
                      fill="currentColor"
                      strokeWidth="0"
                      viewBox="0 0 512 512"
                      className="link__arrow"
                      size={20}
                      height="20"
                      width="20"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path d="M294.1 256L167 129c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.3 34 0L345 239c9.1 9.1 9.3 23.7.7 33.1L201.1 417c-4.7 4.7-10.9 7-17 7s-12.3-2.3-17-7c-9.4-9.4-9.4-24.6 0-33.9l127-127.1z"></path>
                    </svg>
                  </a>
                </Link>
                <Link href="/invite-friend">
                  <a className="link" href="">
                    <img className="link__icon" src="images/document.svg" />
                    <div className="link__content">Giới thiệu người mua</div>
                    <svg
                      stroke="currentColor"
                      fill="currentColor"
                      strokeWidth="0"
                      viewBox="0 0 512 512"
                      className="link__arrow"
                      size={20}
                      height="20"
                      width="20"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path d="M294.1 256L167 129c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.3 34 0L345 239c9.1 9.1 9.3 23.7.7 33.1L201.1 417c-4.7 4.7-10.9 7-17 7s-12.3-2.3-17-7c-9.4-9.4-9.4-24.6 0-33.9l127-127.1z"></path>
                    </svg>
                  </a>
                </Link>
              </div>
              <div className="group">
                <a className="link" href="">
                  <img className="link__icon" src="images/search.svg" />
                  <div className="link__content">Sổ địa chỉ</div>
                  <svg
                    stroke="currentColor"
                    fill="currentColor"
                    strokeWidth="0"
                    viewBox="0 0 512 512"
                    className="link__arrow"
                    size={20}
                    height="20"
                    width="20"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M294.1 256L167 129c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.3 34 0L345 239c9.1 9.1 9.3 23.7.7 33.1L201.1 417c-4.7 4.7-10.9 7-17 7s-12.3-2.3-17-7c-9.4-9.4-9.4-24.6 0-33.9l127-127.1z"></path>
                  </svg>
                </a>
                <a className="link" href="">
                  <img className="link__icon" src="images/home1.svg" />
                  <div className="link__content">Thông tin thanh toán</div>
                  <svg
                    stroke="currentColor"
                    fill="currentColor"
                    strokeWidth="0"
                    viewBox="0 0 512 512"
                    className="link__arrow"
                    size={20}
                    height="20"
                    width="20"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M294.1 256L167 129c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.3 34 0L345 239c9.1 9.1 9.3 23.7.7 33.1L201.1 417c-4.7 4.7-10.9 7-17 7s-12.3-2.3-17-7c-9.4-9.4-9.4-24.6 0-33.9l127-127.1z"></path>
                  </svg>
                </a>
              </div>
              <div className="group">
                <a className="link" href="">
                  <img className="link__icon" src="images/home.svg" />
                  <div className="link__content">Sản phẩm đã mua</div>
                  <svg
                    stroke="currentColor"
                    fill="currentColor"
                    strokeWidth="0"
                    viewBox="0 0 512 512"
                    className="link__arrow"
                    size={20}
                    height="20"
                    width="20"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M294.1 256L167 129c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.3 34 0L345 239c9.1 9.1 9.3 23.7.7 33.1L201.1 417c-4.7 4.7-10.9 7-17 7s-12.3-2.3-17-7c-9.4-9.4-9.4-24.6 0-33.9l127-127.1z"></path>
                  </svg>
                </a>
                <a className="link" href="">
                  <img className="link__icon" src="images/Eye.svg" />
                  <div className="link__content">Sản phẩm đã xem</div>
                  <svg
                    stroke="currentColor"
                    fill="currentColor"
                    strokeWidth="0"
                    viewBox="0 0 512 512"
                    className="link__arrow"
                    size={20}
                    height="20"
                    width="20"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M294.1 256L167 129c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.3 34 0L345 239c9.1 9.1 9.3 23.7.7 33.1L201.1 417c-4.7 4.7-10.9 7-17 7s-12.3-2.3-17-7c-9.4-9.4-9.4-24.6 0-33.9l127-127.1z"></path>
                  </svg>
                </a>
                <a className="link" href="">
                  <img className="link__icon" src="images/heart1.svg" />
                  <div className="link__content">Sản phẩm yêu thích</div>
                  <svg
                    stroke="currentColor"
                    fill="currentColor"
                    strokeWidth="0"
                    viewBox="0 0 512 512"
                    className="link__arrow"
                    size={20}
                    height="20"
                    width="20"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M294.1 256L167 129c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.3 34 0L345 239c9.1 9.1 9.3 23.7.7 33.1L201.1 417c-4.7 4.7-10.9 7-17 7s-12.3-2.3-17-7c-9.4-9.4-9.4-24.6 0-33.9l127-127.1z"></path>
                  </svg>
                </a>
              </div>
            </ShortcutWrapper>
          </ContentV2>
          <FooterV2 />
        </ProfileWrapper>
        {/* <Modal>
          <PageWrapper>
            <SidebarSection>
              <Sidebar />
            </SidebarSection>
            <ContentBox>
              <SettingsContent deviceType={deviceType} />
            </ContentBox>

            <Footer />
          </PageWrapper>
        </Modal> */}
      </ProfileProvider>
    </>
  );
};

export default ProfilePage;
