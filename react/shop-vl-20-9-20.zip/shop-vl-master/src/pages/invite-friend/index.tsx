import React, { useState, use } from "react";
import { NextPage } from "next";
import { Modal } from "@redq/reuse-modal";
import { ProfileProvider } from "contexts/profile/profile.provider";
import SettingsContent from "features/user-profile/settings/settings";
import {
  PageWrapper,
  SidebarSection,
  ContentBox,
} from "features/user-profile/user-profile.style";
import Sidebar from "features/user-profile/sidebar/sidebar";
import { SEO } from "components/seo";
import Footer from "layouts/footer";
import HeaderV2 from "layouts/HeaderV2";
import FooterV2 from "layouts/FooterV2";
import ContentV2 from "layouts/ContentV2";
import ErrorMessage from "components/error-message/error-message";
import Tabs from "components/tabs";
import useUser from "data/use-user";
import styled from "styled-components";

import { isPhone, isEmail } from 'utils/validate';

import axios from "utils/api/axios";

const fetcher = (url, body) => axios.post(url, body).then((res) => res.data);


type Props = {
  deviceType?: {
    mobile: boolean;
    tablet: boolean;
    desktop: boolean;
  };
};

const ShortcutWrapper = styled.div`
  .form-box {
    padding: 16px;
  }
  .form-control-invite {
    width: 100%;
    height: 56px;
    border: 1px solid #c9d2d7;
    font-size: 14px;
    padding: 0 16px;
    outline: none;
    border-collapse: collapse;
    line-height: 1;
    -webkit-box-shadow: 0px 0.92px 23px rgba(0, 0, 0, 0.08);
    box-shadow: 0px 0.92px 23px rgba(0, 0, 0, 0.08);
    border-radius: 6px;
    position: relative;
    z-index: 2;
    background: transparent;
    &.area-input {
      height: auto;
      padding: 16px;
    }
    &.customer {
      padding-right: 40px;
    }
    &.btn-submit {
      max-width: 130px;
      cursor: pointer;
    }
  }
  .form-group {
    position: relative;
    &:not(:first-child) {
      margin-top: 16px;
    }
    &.customer-gr {
      &:after {
        content: "";
        position: absolute;
        width: 24px;
        height: 24px;
        background: url(../images/call.svg) center no-repeat;
        right: 10px;
        top: 15px;
        color: #31ae4a;
        font-weight: 500;
        font-size: 1.6rem;
        z-index: 5;
      }
    }
    label {
      color: #777777;
      margin-left: 5px;
      position: absolute;
    }
  }
  .error {
    color: red;
    font-size: 12px;
    margin: 3px;
  }
  .success {
    color: green;
    font-size: 15px;
    margin-left: 15px;
  }
  input[type="checkbox"] {
    width: 16px;
    height: 16px;
  }
  @media (min-width: 768px) {
    .form-control-invite {
      font-size: 16px;
    }
  }
`;

const DEFAULT_STATE = {
  request_phone: false,
  request_now: false,
  name: "",
  phone: "",
  email: "",
  address: "",
  note: "",
}

const FormInviteFriend = ({ onSubmit }) => {
  const [state, updateState] = useState(DEFAULT_STATE);

  const [error, updateError] = useState({
    name: null,
    phone: null,
    email: null,
  });

  const handleChange = (prop) => (event) => {
    updateState({ ...state, [prop]: event.target.value });
    updateError({ ...error, [prop]: null });
  };

  const handleChangeCheckbox = (prop) => (event) => {
    updateState({ ...state, [prop]: event.target.checked });
  };

  const validate = () => {
    const { name, phone, email } = state;
    const newError = { ...error };
    if (!name) {
      newError.name = 'Vui lòng nhập tên'
    }
    if (!phone || !isPhone(phone)) {
      newError.phone = 'Số điện thoại không hợp lệ'
    }
    if (!email || !isEmail(email)) {
      newError.email = 'Email không hợp lệ'
    }
    updateError(newError);
    return !newError.name && !newError.phone && !newError.email;
  }

  const handleSubmit = (event) => {
    event.preventDefault();
    const isValid = validate();
    if (isValid) {
      onSubmit(state, () => {
        updateState(DEFAULT_STATE)
      });
    }
  };

  return (
    <form className="form-box" onSubmit={handleSubmit}>
      <div className="form-group">
        <input
          type="checkbox"
          id="chk1"
          name="chk1"
          value={state.request_phone}
          onChange={handleChangeCheckbox("request_phone")}
        />
        <label htmlFor="chk1"> Đã thông báo sẽ gọi điện</label>
        <br />
      </div>
      <div className="form-group">
        <input
          type="checkbox"
          id="chk2"
          name="chk2"
          value={state.request_now}
          onChange={handleChangeCheckbox("request_now")}
        />
        <label htmlFor="chk2"> Cần gọi lại ngay</label>
        <br />
      </div>
      <div className="form-group customer-gr">
        <input
          required
          placeholder="Khách hàng"
          type="text"
          className="form-control form-control-invite customer"
          value={state.name}
          onChange={handleChange("name")}
        />
      </div>
      {!!error.name && (
        <p className="error">{error.name}</p>
      )}
      <div className="form-group">
        <input
          required
          placeholder="Điện thoại"
          type="tel"
          className="form-control form-control-invite"
          value={state.phone}
          onChange={handleChange("phone")}
        />
      </div>
      {!!error.phone && (
        <p className="error">{error.phone}</p>
      )}
      <div className="form-group">
        <input
          required
          placeholder="Email"
          type="email"
          className="form-control form-control-invite"
          value={state.email}
          onChange={handleChange("email")}
        />
      </div>
      {!!error.email && (
        <p className="error">{error.email}</p>
      )}
      <div className="form-group">
        <textarea
          name="area-address"
          className="form-control form-control-invite area-input"
          rows={3}
          placeholder="Địa chỉ"
          value={state.address}
          onChange={handleChange("address")}
        />
      </div>
      <div className="form-group">
        <textarea
          name="area-note"
          className="form-control form-control-invite area-input"
          rows={3}
          placeholder="Ghi chú"
          value={state.note}
          onChange={handleChange("note")}
        />
      </div>
      <div className="form-group">
        <button
          type="submit"
          className="form-control form-control-invite btn-submit"
          placeholder="Xác nhận"
        >
          Xác nhận
        </button>
      </div>
    </form>
  );
};

const ProfilePage: NextPage<Props> = ({ deviceType }) => {
  const { user, error } = useUser();
  if (error) return <ErrorMessage message={error.message} />;
  if (!user) return <div>loading...</div>;

  const [state, updateState] = useState({
    success: false,
    loading: false,
    errorMessage: "",
  })

  const handleInviteFriend = async (inviteData, callback) => {
    try {
      updateState({ ...state, loading: true });
      const { success, data } = await fetcher('/suggest-friend', inviteData);
      callback()
      updateState({ ...state, loading: false, success: true });
    } catch (error) {
      updateState({ ...state, loading: false, errorMessage: error.message });
    }
  }

  return (
    <>
      <SEO title="Profile - PickBazar" description="Profile Details" />
      <ProfileProvider initData={user}>
        <HeaderV2 title="Mời bạn" />
        <ContentV2>
          <ShortcutWrapper>
            <div className="list-order">
              <Tabs />
              <div className="list-order-content" id="tab1">
                <FormInviteFriend onSubmit={handleInviteFriend} />
                {state.success && <p className="success">Giới thiệu thành công!</p>}
                {state.loading && <div>loading...</div>}
                {state.errorMessage && <div>{state.errorMessage}</div>}
              </div>
            </div>
          </ShortcutWrapper>
        </ContentV2>
        <FooterV2 />
      </ProfileProvider>
    </>
  );
};

export default ProfilePage;
