import React, { useState, useEffect } from "react";
import InfiniteScroll from "react-infinite-scroll-component";
import { NextPage } from "next";
import { Modal } from "@redq/reuse-modal";
import { ProfileProvider } from "contexts/profile/profile.provider";
import SettingsContent from "features/user-profile/settings/settings";
import {
  PageWrapper,
  SidebarSection,
  ContentBox,
} from "features/user-profile/user-profile.style";
import Sidebar from "features/user-profile/sidebar/sidebar";
import { SEO } from "components/seo";
import Tabs from "components/tabs";
import Footer from "layouts/footer";
import HeaderV2 from "layouts/HeaderV2";
import FooterV2 from "layouts/FooterV2";
import ContentV2 from "layouts/ContentV2";
import ErrorMessage from "components/error-message/error-message";
import useUser from "data/use-user";
import styled from "styled-components";

import axios from "utils/api/axios";

const fetcher = (url) => axios.get(url).then((res) => res.data);
const fetcherPut = (url) => axios.put(url).then((res) => res.data);

type Props = {
  deviceType?: {
    mobile: boolean;
    tablet: boolean;
    desktop: boolean;
  };
};

const ShortcutWrapper = styled.div`
  .trash {
    display: block;
    width: 24px;
    height: 24px;
    background: url(../images/trash.svg) no-repeat;
    margin-right: 8px;
  }
  .code-invite {
    padding: 16px 16px;
    display: flex;
    justify-content: space-between;
    background: #aeadbf;
    color: #ffffff;
    align-items: center;
    .inv-code {
      font-weight: bold;
      font-size: 20px;
    }
  }
  .list-invite {
    .invite-item {
      display: flex;
      justify-content: space-between;
      padding: 16px;
      border-bottom: 1px solid #aeadbf;
      .inv-info-name {
        font-size: 18px;
      }
      .inv-button {
        display: block;
        padding: 10px 20px;
        color: #5bb197;
        border: 2px solid #5bb197;
        border-radius: 6px;
        cursor: pointer;
      }
    }
  }
  .question {
    text-decoration: underline;
    font-style: italic;
  }
`;

const LIMIT = 20;

const ProfilePage: NextPage<Props> = ({ deviceType }) => {
  const { user, error } = useUser();
  if (error) return <ErrorMessage message={error.message} />;
  if (!user) return <div>loading...</div>;

  const [state, updateState] = useState({
    docs: [],
    total: 0,
    page: 0,
    loading: false,
    errorMessage: "",
  });

  const fetchMoreData = async () => {
    try {
      updateState({ ...state, loading: true });
      const { success, data } = await fetcher(
        `/suggest-friend/find?limit=${LIMIT}&page=${state.page + 1}`
      );
      const { totalDocs, docs } = data;
      updateState({
        ...state,
        total: totalDocs,
        docs: [...state.docs, ...docs],
        page: state.page + 1,
        loading: false,
      });
    } catch (error) {
      updateState({ ...state, loading: false, errorMessage: error.message });
    }
  };

  useEffect(() => {
    fetchMoreData();
  }, []);

  const handleResendInviteRequest = async (requestId) => {
    try {
      updateState({ ...state, loading: true });
      const { success, data } = await fetcherPut(
        `suggest-friend/action/${requestId}`
      );
      updateState({ ...state, loading: false });
    } catch (error) {
      updateState({ ...state, loading: false, errorMessage: error.message });
    }
  };

  return (
    <>
      <SEO title="Profile - PickBazar" description="Profile Details" />
      <ProfileProvider initData={user}>
        <HeaderV2 title="Cần xử lý" />
        <ContentV2>
          <ShortcutWrapper>
            <div className="list-order">
              <Tabs />
              <div className="list-order-content" id="tab1">
                <div className="code-invite">
                  <div>
                    Mã giới thiệu: <span className="inv-code">{user.id}</span>
                  </div>
                  <div>
                    <a className="question">Đây là gì?</a>
                  </div>
                </div>
                <div className="list-invite">
                  <InfiniteScroll
                    dataLength={state.docs.length}
                    next={fetchMoreData}
                    hasMore={state.total > state.docs.length}
                    loader={<h4>Loading...</h4>}
                  >
                    {state.docs.map(({ name, email, _id }) => (
                      <div className="invite-item">
                        <div className="inv-info">
                          <div className="inv-info-name">{name}</div>
                          <div className="inv-info-mail">{email}</div>
                        </div>
                        <div
                          className="inv-button"
                          onClick={() => handleResendInviteRequest(_id)}
                        >
                          Gửi lại
                        </div>
                      </div>
                    ))}
                  </InfiniteScroll>
                  {/* <div className="invite-item">
										<div className="inv-info">
											<div className="inv-info-name">Vân</div>
											<div className="inv-info-mail">vantran@cleon.vn</div>
										</div>
										<div className="inv-button">Gửi lại</div>
									</div>
									<div className="invite-item">
										<div className="inv-info">
											<div className="inv-info-name">Vân</div>
											<div className="inv-info-mail">vantran@cleon.vn</div>
										</div>
										<div className="inv-button">Gửi lại</div>
									</div>
									<div className="invite-item">
										<div className="inv-info">
											<div className="inv-info-name">Vân</div>
											<div className="inv-info-mail">vantran@cleon.vn</div>
										</div>
										<div className="inv-button">Gửi lại</div>
									</div><div className="invite-item">
										<div className="inv-info">
											<div className="inv-info-name">Vân</div>
											<div className="inv-info-mail">vantran@cleon.vn</div>
										</div>
										<div className="inv-button">Gửi lại</div>
									</div><div className="invite-item">
										<div className="inv-info">
											<div className="inv-info-name">Vân</div>
											<div className="inv-info-mail">vantran@cleon.vn</div>
										</div>
										<div className="inv-button">Gửi lại</div>
									</div> */}
                </div>
              </div>
              <div className="list-order-content" id="tab2"></div>
            </div>
          </ShortcutWrapper>
        </ContentV2>
        <FooterV2 />
      </ProfileProvider>
    </>
  );
};

export default ProfilePage;
