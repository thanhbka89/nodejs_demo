import React, { useState, useEffect } from "react";
import { NextPage } from "next";
import { Modal } from "@redq/reuse-modal";
import { ProfileProvider } from "contexts/profile/profile.provider";
import { format } from "date-fns";
import InfiniteScroll from "react-infinite-scroll-component";
import SettingsContent from "features/user-profile/settings/settings";
import {
  PageWrapper,
  SidebarSection,
  ContentBox,
} from "features/user-profile/user-profile.style";
import Sidebar from "features/user-profile/sidebar/sidebar";
import { SEO } from "components/seo";
import Footer from "layouts/footer";
import HeaderV2 from "layouts/HeaderV2";
import FooterV2 from "layouts/FooterV2";
import ContentV2 from "layouts/ContentV2";
import ErrorMessage from "components/error-message/error-message";
import useUser from "data/use-user";
import styled from "styled-components";
import { getPointFormat } from "utils/helper";

import axios from "utils/api/axios";

const fetcher = (url) => axios.get(url).then((res) => res.data);

type Props = {
  deviceType?: {
    mobile: boolean;
    tablet: boolean;
    desktop: boolean;
  };
};

const CoinWrapper = styled.div`
  .Reward__item {
    padding: 7px 16px;
    border-bottom: 1px solid rgb(242, 242, 242);
    font-size: 16px;
    position: relative;
    color: rgb(51, 51, 51);
    background: rgb(255, 255, 255);
    p {
      margin: 10px 0px;
    }
    .Reward__item__number {
      color: rgb(38, 188, 78);
      font-size: 16px;
      &.number--am {
        color: #f90f25;
      }
    }
    .Reward__item__date {
      color: rgb(120, 120, 120);
      font-size: 11px;
    }
    .Reward__item__content {
      font-size: 13px;
      line-height: 18px;
    }
  }
`;

const LIMIT = 20;

const CoinPage: NextPage<Props> = ({ deviceType }) => {
  const { user, error } = useUser();
  if (error) return <ErrorMessage message={error.message} />;
  if (!user) return <div>loading...</div>;

  const [state, updateState] = useState({
    docs: [],
    total: 0,
    page: 0,
    loading: false,
    errorMessage: "",
  });

  const fetchMoreData = async () => {
    try {
      updateState({ ...state, loading: true });
      const { success, data } = await fetcher(
        `payment-log/find?limit=${LIMIT}&page=${state.page + 1}`
      );
      const { totalDocs, docs } = data;
      updateState({
        ...state,
        total: totalDocs,
        docs: [...state.docs, ...docs],
        page: state.page + 1,
        loading: false,
      });
    } catch (error) {
      updateState({ ...state, loading: false, errorMessage: error.message });
    }
  };

  useEffect(() => {
    fetchMoreData();
  }, []);

  return (
    <>
      <SEO title="Profile - PickBazar" description="Profile Details" />
      <ProfileProvider initData={user}>
        <HeaderV2 title="Lịch sử xu" />
        <ContentV2>
          <CoinWrapper>
            <div className="Reward-coin">
              <div className="Reward__content">
                <ul>
                  <div
                    className="infinite-scroll-component"
                    style={{ height: "auto", overflow: "auto" }}
                  >
                    <InfiniteScroll
                      dataLength={state.docs.length}
                      next={fetchMoreData}
                      hasMore={state.total > state.docs.length}
                      loader={<h4>Loading...</h4>}
                    >
                      {state.docs.map(({ point, transaction, createdAt }) => (
                        <li className="Reward__item">
                          <p className="Reward__item__number">
                            <span>{getPointFormat(point)}</span>
                          </p>
                          <p className="Reward__item__date">
                            Đã chấp nhận{" "}
                            {format(new Date(createdAt), "dd/MM/yyyy")}
                          </p>
                          <p className="Reward__item__content">{transaction}</p>
                        </li>
                      ))}
                    </InfiniteScroll>
                    {state.loading && <div>loading...</div>}
                    {state.errorMessage && (
                      <ErrorMessage message={state.errorMessage} />
                    )}
                  </div>
                </ul>
              </div>
            </div>
          </CoinWrapper>
        </ContentV2>
        <FooterV2 />
      </ProfileProvider>
    </>
  );
};

export default CoinPage;
