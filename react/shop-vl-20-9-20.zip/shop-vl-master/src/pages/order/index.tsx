import React, { useState, useEffect } from "react";
import { NextPage } from "next";
import Link from "next/link";
import useSWR from "swr";
import { format } from "date-fns";
import InfiniteScroll from "react-infinite-scroll-component";
import { SEO } from "components/seo";
import ErrorMessage from "components/error-message/error-message";
import Order from "features/user-profile/order/order";
import {
  PageWrapper,
  SidebarSection,
} from "features/user-profile/user-profile.style";
import Sidebar from "features/user-profile/sidebar/sidebar";
import { Modal } from "@redq/reuse-modal";
import styled from "styled-components";

import HeaderV2 from "layouts/HeaderV2";
import FooterV2 from "layouts/FooterV2";
import ContentV2 from "layouts/ContentV2";

import axios from "utils/api/axios";

const fetcher = (url) => axios.get(url).then((res) => res.data);

const OrderPageWrapper = styled.div`
  .list-order {
    ul {
      padding-left: 0px;
      list-style: none;
    }
  }
  li {
    list-style-type: none;
  }
  .list-order-tabs {
    padding-left: 0px;
    border-bottom: 1px solid rgb(224, 224, 224);
    margin-bottom: 0px;
    > li {
      display: inline-block;
      width: calc(50% - 2px);
      text-align: center;
      padding: 15px 10px;
      font-weight: 500;
      color: rgba(0, 0, 0, 0.54);
      font-size: 0.875rem;
      position: relative;
      &.active {
        color: rgb(27, 168, 255);
        &::before {
          width: 100%;
          height: 2px;
          position: absolute;
          bottom: 0px;
          left: 0px;
          background: rgb(27, 168, 255);
          content: "";
        }
      }
    }
  }

  .list-order__item {
    padding: 16px;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    border-bottom: 1px solid rgb(224, 224, 224);
    -webkit-box-pack: justify;
    justify-content: space-between;
  }
  .list-order__item__description {
    color: rgb(51, 51, 51);
    font-size: 16px;
    font-weight: 400;
    line-height: 24px;
    margin-bottom: 8px;
  }
  .list-order__item__content {
    color: rgb(117, 117, 117);
  }
`;

const LIMIT = 20;

const OrderPage: NextPage = () => {
  const [state, updateState] = useState({
    orders: [],
    total: 0,
    page: 0,
    loading: false,
    errorMessage: "",
  });

  const fetchMoreData = async () => {
    try {
      updateState({ ...state, loading: true });
      const { success, data } = await fetcher(
        `/order/detail/find?populate=product,order&limit=${LIMIT}&page=${
          state.page + 1
        }`
      );
      const { totalDocs, docs } = data;
      updateState({
        ...state,
        total: totalDocs,
        orders: [...state.orders, ...docs],
        page: state.page + 1,
        loading: false,
      });
    } catch (error) {
      updateState({ ...state, loading: false, errorMessage: error.message });
    }
  };

  useEffect(() => {
    fetchMoreData();
  }, []);

  return (
    <>
      <SEO title="Order - PickBazar" description="Order Details" />
      <HeaderV2 title="Quản lý đơn hàng" />
      <ContentV2>
        <OrderPageWrapper>
          <div className="list-order">
            <ul className="list-order-tabs">
              <li className="active" data-href="#tab1">
                Danh Sách Đơn
              </li>
              <li className="false" data-href="#tab2">
                EVoucher Của Tôi
              </li>
            </ul>
            <div
              className="list-order-content infinite-scroll-component"
              id="tab1"
            >
              <InfiniteScroll
                dataLength={state.orders.length}
                next={fetchMoreData}
                hasMore={state.total > state.orders.length}
                loader={<h4>Loading...</h4>}
              >
                {state.orders.map(
                  ({ id, product = {}, order = {}, createdAt }) => (
                    <Link href="/order/[orderId]" as={`/order/${order._id}`}>
                      <a>
                        <div className="list-order__item">
                          <div>
                            <div className="list-order__item__description">
                              {product.name}
                            </div>
                            <div className="list-order__item__content">
                              Mã đơn hàng: {id} <br />
                              Ngày đặt hàng:{" "}
                              {format(new Date(createdAt), "dd/MM/yyyy")}
                              <br />
                              Trạng thái: {order.status}
                              <br />
                            </div>
                          </div>
                          <svg
                            stroke="currentColor"
                            fill="currentColor"
                            strokeWidth="0"
                            viewBox="0 0 512 512"
                            height="1em"
                            width="1em"
                            xmlns="http://www.w3.org/2000/svg"
                            style={{
                              color: "rgb(0, 150, 136)",
                              fontSize: "24px",
                              minWidth: "24px",
                            }}
                          >
                            <path d="M256 48C141.1 48 48 141.1 48 256s93.1 208 208 208 208-93.1 208-208S370.9 48 256 48zm106.5 150.5L228.8 332.8h-.1c-1.7 1.7-6.3 5.5-11.6 5.5-3.8 0-8.1-2.1-11.7-5.7l-56-56c-1.6-1.6-1.6-4.1 0-5.7l17.8-17.8c.8-.8 1.8-1.2 2.8-1.2 1 0 2 .4 2.8 1.2l44.4 44.4 122-122.9c.8-.8 1.8-1.2 2.8-1.2 1.1 0 2.1.4 2.8 1.2l17.5 18.1c1.8 1.7 1.8 4.2.2 5.8z"></path>
                          </svg>
                        </div>
                      </a>
                    </Link>
                  )
                )}
              </InfiniteScroll>
              {state.loading && <div>loading...</div>}
              {state.errorMessage && <ErrorMessage message={error.message} />}
            </div>
            <div className="list-order-content" id="tab2"></div>
          </div>
        </OrderPageWrapper>
      </ContentV2>
      <FooterV2 />
      {/* <Modal>
        <PageWrapper>
          <SidebarSection>
            <Sidebar />
          </SidebarSection>
          <Order />
        </PageWrapper>
      </Modal> */}
    </>
  );
};

export default OrderPage;
