import React, { useState, useEffect } from "react";
import { format } from "date-fns";
import { NextPage } from "next";
import { useRouter } from "next/router";
import Link from "next/link";
import { SEO } from "components/seo";
import Order from "features/user-profile/order/order";
import {
  PageWrapper,
  SidebarSection,
} from "features/user-profile/user-profile.style";
import Sidebar from "features/user-profile/sidebar/sidebar";
import { Modal } from "@redq/reuse-modal";
import styled from "styled-components";

import HeaderV2 from "layouts/HeaderV2";
import FooterV2 from "layouts/FooterV2";
import ContentV2 from "layouts/ContentV2";

import axios from "utils/api/axios";

const fetcher = (url) => axios.get(url).then((res) => res.data);

const OrderDetailPageWrapper = styled.div`
  .order-detail-list {
    padding: 10px 16px;
    color: #333333;
    -webkit-box-align: center;
    align-items: center;
    text-decoration: none;
    margin: 0px 0px 1px;
    background-color: white;
    > .title {
      color: #000000;
      font-size: 15px;
      margin-bottom: 10px;
    }
    > .order-detail__if {
      color: #333333;
      font-size: 13px;
      margin-bottom: 5px;
    }
    > .order-status {
      &.order-success {
        color: #2f8f85;
      }
      &.order-fail {
        color: #f90f25;
      }
    }
  }
  .btn-order {
    display: inline-block;
    background: #03a9f5;
    padding: 10px 16px;
    margin: auto;
    text-align: center;
    color: #ffffff;
    cursor: pointer;
    margin-top: 10px;
    position: relative;
  }
  .order-follow__title {
    padding: 16px;
    color: #737373;
    font-size: 16px;
    border-bottom: 1px solid #dfdfdf;
  }
  .order-status-timer {
    padding: 16px;
    display: flex;
    justify-content: start;
    color: #000000;
    font-size: 16px;
    > .od-col {
      margin-right: 10px;
    }
    > .od-line {
      width: 12px;
      border-radius: 10px;
      background: #6aab35;
    }
    > .od-detail {
      p:not(:last-child) {
        margin-top: 0;
        margin-bottom: 10px;
      }
    }
  }
  .order-table-inner {
    padding: 0 16px;
    margin: 0 auto;
    width: 100%;

    > .order-table {
      width: 100%;
      background: #ffffff;
      border: 1px solid #dfdfdf;
      border-collapse: collapse;
    }
    > tr {
      background: #ffffff;
      border-top: 1px solid #c1c3d1;
      color: #666b85;
      font-size: 16px;
      font-weight: normal;
      &.tr-title {
        background: #f3f3f3;
        color: #000000;
        font-weight: bold;
      }
      > td {
        padding: 16px;
      }
    }
  }
`;

const OrderDetailPage: NextPage = () => {
  const router = useRouter();

  const [state, updateState] = useState({
    order: {},
    loading: false,
    errorMessage: "",
  });

  const getOrderDetail = async (orderId) => {
    try {
      updateState({ ...state, loading: true });
      const { success, data } = await fetcher(`order/action/${orderId}`);
      updateState({
        ...state,
        order: data,
        loading: false,
      });
    } catch (error) {
      updateState({ ...state, loading: false, errorMessage: error.message });
    }
  };

  useEffect(() => {
    // console.log("router", router.query.orderId);
    const [, , orderId] = window.location.pathname.split("/");
    getOrderDetail(orderId);
  }, []);

  return (
    <>
      <SEO title="Order - PickBazar" description="Order Details" />
      <HeaderV2 title="Đơn hàng" />
      <ContentV2>
        <OrderDetailPageWrapper>
          <div className="Order-detail">
            <div className="group">
              <div className="order-detail-list">
                <div className="title">Mã đơn hàng: {state.order._id}</div>
                <p className="order-detail__if">
                  Ngày đặt hàng:{" "}
                  {state.order.createdAt &&
                    format(new Date(state.order.createdAt), "dd/MM/yyyy")}
                </p>
                <p className="order-detail__if">
                  Trạng thái: {state.order.status}
                </p>
              </div>
            </div>
            <div className="group">
              <div className="order-detail-list">
                <div className="title">Địa chỉ người nhận</div>
                <p className="order-detail__if">
                  {(state.order.customer || {}).fullname}
                </p>
                <p className="order-detail__if">
                  {(state.order.customer || {}).mobile}
                </p>
                <p className="order-detail__if">{state.order.shipping}</p>
              </div>
            </div>
            <div className="group">
              <div className="order-detail-list">
                <div className="title">Hình thức giao hàng</div>
                <p className="order-detail__if">
                  Giao hàng tiêu chuẩn(dự kiến giao năm sau)
                </p>
              </div>
            </div>
            <div className="group">
              <div className="order-detail-list">
                <div className="title">Thông tin vận chuyển</div>
                <p className="order-status order-success">
                  Giao hàng thành công
                </p>
                <Link
                  href="/order/[orderId]/track"
                  as={`/order/${state.order._id}/track`}
                >
                  <div className="btn-order btn-folow">Theo dõi đơn hàng</div>
                </Link>
              </div>
            </div>
            <div className="group">
              <div className="order-detail-list">
                <div className="title">Hình thức thanh toán</div>
                <p className="order-detail__if">{state.order.payment}</p>
              </div>
            </div>
          </div>
        </OrderDetailPageWrapper>
      </ContentV2>
      <FooterV2 />
      {/* <Modal>
        <PageWrapper>
          <SidebarSection>
            <Sidebar />
          </SidebarSection>
          <Order />
        </PageWrapper>
      </Modal> */}
    </>
  );
};

export default OrderDetailPage;
