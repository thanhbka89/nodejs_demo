import { NextPage } from 'next';
import { Modal } from '@redq/reuse-modal';
import { ProfileProvider } from 'contexts/profile/profile.provider';
import SettingsContent from 'features/user-profile/settings/settings';
import {
  PageWrapper,
  SidebarSection,
  ContentBox,
} from 'features/user-profile/user-profile.style';
import Sidebar from 'features/user-profile/sidebar/sidebar';
import { SEO } from 'components/seo';
import Footer from 'layouts/footer';
import HeaderV2 from 'layouts/HeaderV2';
import FooterV2 from 'layouts/FooterV2';
import ContentV2 from 'layouts/ContentV2';
import ErrorMessage from 'components/error-message/error-message';
import useUser from 'data/use-user';
import styled from 'styled-components';

type Props = {
  deviceType?: {
    mobile: boolean;
    tablet: boolean;
    desktop: boolean;
  };
};

const OrderTrackingWrapper = styled.div`
.order-detail-list{
  padding: 10px 16px;
  color: #333333;
  -webkit-box-align: center;
  align-items: center;
  text-decoration: none;
  margin: 0px 0px 1px;
  background-color: white;
  .title{
    color: #000000;
    font-size: 15px;
    margin-bottom: 10px;
  }
  .order-detail__if{
    color: #333333;
    font-size: 13px;
    margin-bottom: 5px;
  }
  .order-status{
    &.order-success{
      color: #2f8f85;
    }
    &.order-fail{
      color: #f90f25;;
    }
  }
}
.btn-order{
  display: inline-block;
  background: #03a9f5;
  padding: 10px 16px;
  margin: auto;
  text-align: center;
  color: #ffffff;
  cursor: pointer;
  margin-top: 10px;
  position: relative;
}
.order-follow__title{
  padding: 16px;
  color: #737373;
  font-size: 16px;
  border-bottom: 1px solid #dfdfdf;
}
.order-status-timer{
  padding: 16px;
  display: flex;
  justify-content: start;
  color: #000000;
  font-size: 16px;
  .od-col{
    margin-right: 10px;
  }
  .od-line{
    width: 12px;
    border-radius: 10px;
    background: #6aab35;
  }
  .od-detail{
    p:not(:last-child){
      margin-top: 0;
      margin-bottom: 10px;
    }
  }
}
.order-table-inner{
  padding: 0 16px;
  margin: 0 auto;
  width: 100%;

  .order-table{
    width: 100%;
    background: #ffffff;
    border: 1px solid #DFDFDF;
    border-collapse: collapse;
  }
  tr{
    background: #ffffff;
    border-top: 1px solid #C1C3D1;
    color: #666B85;
    font-size: 16px;
    font-weight: normal;
    &.tr-title{
      background: #F3F3F3;
      color: #000000;
      font-weight: bold;
    }
    td {
      padding: 16px;
      border-bottom-style: unset !important;
    }
  }
}
`;


const OrderTrackingPage: NextPage<Props> = ({ deviceType }) => {
  const { user, error } = useUser();
  if (error) return <ErrorMessage message={error.message} />;
  if (!user) return <div>loading...</div>;

  return (
    <>
      <SEO title="Profile - PickBazar" description="Profile Details" />
      <ProfileProvider initData={user}>
        {/* <ProfileWrapper> */}
        <HeaderV2 title="Theo dõi đơn hàng" />
        <ContentV2>
          <OrderTrackingWrapper>
            <div className="order-follow">
              <div className="order-follow__title">Trạng thái đơn hàng</div>
              <div className="order-status-timer">
                <div className="od-col od-date">18/4</div>
                <div className="od-col od-line"></div>
                <div className="od-col od-detail">
                  <p>Đặt hàng thành công</p>
                  <p>Tiki tiếp nhận</p>
                  <p>Đang lấy hàng</p>
                  <p>Đóng gói xong</p>
                  <p>Bàn giao vận chuyển</p>
                  <p>Đang vận chuyển</p>
                  <p>Giao hàng thành công</p>
                </div>
              </div>
              <div className="order-table-inner">
                <table className="order-table">
                  <tr className="tr-title">
                    <td colSpan={2}>Cập nhật mới nhất: Thứ tư, 22/4/2020</td>
                  </tr>
                  <tr>
                    <td>10:50</td>
                    <td>Giao hàng thành công</td>
                  </tr>
                  <tr>
                    <td>8:15</td>
                    <td>Đang vận chuyển</td>
                  </tr>
                  <tr className="tr-title">
                    <td colSpan={2}>Thứ ba, 21/4/2020</td>
                  </tr>
                  <tr>
                    <td>10:15</td>
                    <td>Bàn giao vận chuyển</td>
                  </tr>
                  <tr className="tr-title">
                    <td colSpan={2}>Thứ hai, 20/4/2020</td>
                  </tr>
                  <tr>
                    <td>12:15</td>
                    <td>Đóng gói xong</td>
                  </tr>
                </table>
              </div>
            </div>
          </OrderTrackingWrapper>
        </ContentV2>
        <FooterV2 />
        {/* </ProfileWrapper> */}
        {/* <Modal>
          <PageWrapper>
            <SidebarSection>
              <Sidebar />
            </SidebarSection>
            <ContentBox>
              <SettingsContent deviceType={deviceType} />
            </ContentBox>

            <Footer />
          </PageWrapper>
        </Modal> */}
      </ProfileProvider>
    </>
  );
};

export default OrderTrackingPage;
