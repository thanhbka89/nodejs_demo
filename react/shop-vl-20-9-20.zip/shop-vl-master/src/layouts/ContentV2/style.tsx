import styled from 'styled-components';
import { themeGet } from '@styled-system/theme-get';

const FooterV2Wrapper = styled.div`
h1, h2, h3, h4, h5, h6, a, p, span, input, button, select, label, textarea, text, img, ul, li, i, :before, :after, div {
  margin: 0;
  padding: 0;
  outline: none;
  color: inherit;
  text-decoration: none;
}
* {
  margin: 0;
  padding: 0;
  webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
  -webkit-tap-highlight-color: rgba(255, 255, 255, 0);
}
::before, ::after {
  box-sizing: border-box;
}
html, body{
  font-family: Roboto, Helvetica, Arial, sans-serif;
  font-size: 14px;
  background-color: #ffffff;
}
.fix-container {
  margin: 0 auto;
  max-width: 100%;
  position: relative;
}
.main-content{
  min-height: calc(100vh - 56px);
  background: #ffffff;
  padding-bottom: 56px;
  padding-top: 56px;
}
@media (min-width: 768px) {
  .fix-container{
    width: 768px;
  }
  .main-content{
    min-height: calc(100vh - 56px);
    max-width: 768px;
    margin: auto;
    background-color: #ffffff;
    border-left: 1px solid #efefef;
    border-right: 1px solid #efefef;
  }
}
`;

export default FooterV2Wrapper;
