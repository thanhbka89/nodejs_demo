import React from 'react'
import PropTypes from 'prop-types'

import ContentWrapper from './style';

type Props = {
	className?: string;
};

const Content: React.FC<Props> = (props) => {
	return (
		<ContentWrapper>
			<div className="main-content">
				<div className="fix-container">
					{props.children}
				</div>
			</div>
		</ContentWrapper >
	)
}

Content.propTypes = {

}

export default Content

