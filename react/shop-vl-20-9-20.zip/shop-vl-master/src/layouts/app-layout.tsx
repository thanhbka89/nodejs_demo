import React from 'react';
import dynamic from 'next/dynamic';
import { useRouter } from 'next/router';
import Sticky from 'react-stickynode';
import { useMedia } from "utils/use-media";
import { useAppState } from 'contexts/app/app.provider';
import { useCart } from 'contexts/cart/use-cart';
import Header from './header/header';
import FooterV2 from "layouts/FooterV2";
import { LayoutWrapper } from './layout.style';
import { isCategoryPage } from './is-home-page';
const MobileHeader = dynamic(() => import('./header/mobile-header'), {
  ssr: false,
});

type LayoutProps = {
  className?: string;
  token?: string;
};

const Layout: React.FunctionComponent<LayoutProps> = ({
  className,
  children,
  // deviceType: { mobile, tablet, desktop },
  token,
}) => {
  const { cartItemsCount } = useCart();
  const isSticky = useAppState('isSticky');
  const { pathname, query } = useRouter();
  const type = pathname === '/restaurant' ? 'restaurant' : query.type;

  const isHomePage = isCategoryPage(type);
  const mobile = useMedia("(max-width: 580px)");

  return (
    <LayoutWrapper className={`layoutWrapper ${className}`}>
      <Sticky enabled={isSticky} innerZ={1001}>
        {isHomePage && (
          <>
            <MobileHeader
              className={`${isSticky ? 'sticky' : 'unSticky'} ${isHomePage ? 'home' : ''
                } desktop`}
            />

            <Header
              className={`${isSticky && isHomePage ? 'sticky' : 'unSticky'} ${isHomePage ? 'home' : ''
                }`}
            />
          </>
        )}

      </Sticky>
      {children}
      {(mobile) && <FooterV2 />}
    </LayoutWrapper>
  );
};

export default Layout;
