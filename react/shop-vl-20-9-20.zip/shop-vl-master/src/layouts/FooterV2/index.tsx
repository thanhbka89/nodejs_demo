import React from "react";
import PropTypes from "prop-types";
import Link from "next/link";
import { useRouter } from "next/router";

import { AuthContext } from 'contexts/auth/auth.context';
import AuthenticationForm from 'features/authentication-form';
import { openModal } from '@redq/reuse-modal';

import FooterWrapper from "./style";

type Props = {
  className?: string;
};

const Footer: React.FC<Props> = (props) => {
  const router = useRouter();
  const {
    authState: { isAuthenticated },
    authDispatch,
  } = React.useContext<any>(AuthContext);

  const handleJoin = () => {
    authDispatch({
      type: 'SIGNIN',
    });

    openModal({
      show: true,
      overlayClassName: 'quick-view-overlay',
      closeOnClickOutside: true,
      component: AuthenticationForm,
      closeComponent: '',
      config: {
        enableResizing: false,
        disableDragging: true,
        className: 'quick-view-modal',
        width: 458,
        height: 'auto',
      },
    });
  };

  return (
    <FooterWrapper>
      <footer>
        <div id="fixed-menu">
          <div className="fix-container main-menu">
            <Link href="/">
              <a role="presentation" className="btn-cnm active">
                <span className="ic ic-main-menu-home"></span>Trang chủ
              </a>
            </Link>
            <a role="presentation" className="btn-cnm" href="#">
              <span className="ic ic-main-menu-cate"></span>Danh mục
            </a>
            <a className="btn-cnm btnbt-3 " href="#">
              <span className="ic ic-main-menu-search"></span>Tìm kiếm
            </a>
            <a role="presentation" className="btn-cnm" onClick={() => {
              if (isAuthenticated) {
                router.push('/notification')
              } else {
                handleJoin();
              }
            }}>
              <span className="ic ic-main-menu-noti"></span>Thông báo
            </a>
            <a role="presentation" className="btn-cnm" onClick={() => {
              if (isAuthenticated) {
                router.push('/profile')
              } else {
                handleJoin();
              }
            }}>
              <span className="ic ic-main-info"></span>Cá nhân
              </a>
            {/* <Link href="/profile">
            </Link> */}
          </div>
        </div>
      </footer>
    </FooterWrapper>
  );
};

Footer.propTypes = {};

export default Footer;
