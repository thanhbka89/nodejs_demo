import styled from 'styled-components';
import { themeGet } from '@styled-system/theme-get';

const FooterV2Wrapper = styled.div`
#fixed-menu {
  display: block;
  width: 100%;
  position: fixed;
  bottom: 0;
  left: 0;
  z-index: 21;

  .main-menu {
    display: flex;
    padding: 0;
    border-top: 1px solid #dadada;
    background: #fff;
    height: 56px;

    span {
      &.ic {
        width: 30px;
        height: 30px;
        display: inline-block;
        background-repeat: no-repeat;
        background-size: contain;
      }
      &.ic-main-menu-home {
        background-image: url("/images/home1.svg");
      }
      &.ic-main-menu-cate {
        background-image: url("/images/bookmark.svg");
      }
      &.ic-main-menu-search {
        background-image: url("/images/search.svg");
      }
      &.ic-main-menu-noti {
        background-image: url("/images/bell.svg");
      }
      &.ic-main-info {
        background-image: url("/images/person.svg");
      }
    }

    a.btn-cnm {
      display: flex;
      flex-direction: column;
      flex-grow: 1;
      justify-content: center;
      align-items: center;
      font-size: 12px;
      color: #8d8d8d;
    }
  }
}

.fix-container {
  margin: 0 auto;
  max-width: 100%;
  position: relative;
}

@media screen and (min-width: 768px) {
  .fix-container{
    width: 768px;
  }
  .main-menu {
    border-left: 1px solid #dadada;
    border-right: 1px solid #dadada;
    >span{
      .ic {
        margin: 0 3px 0 37px;
      }
    }
  }
}
`;

export default FooterV2Wrapper;
