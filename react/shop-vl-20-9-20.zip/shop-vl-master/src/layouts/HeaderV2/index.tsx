import React from "react";
import { useRouter } from "next/router";
import PropTypes from "prop-types";

import HeaderV2Wrapper from "./style";

type Props = {
  title?: string;
};

const HeaderV2: React.FC<Props> = (props) => {
  const router = useRouter();
  return (
    <HeaderV2Wrapper>
      <header>
        <div className="header-fixed">
          <div className="fix-container">
            <div className="header-main">
              <button className="btn-back" onClick={router.back}>
                <svg
                  stroke="currentColor"
                  fill="currentColor"
                  strokeWidth="0"
                  viewBox="0 0 24 24"
                  size={30}
                  height="30"
                  width="30"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"></path>
                </svg>
              </button>
              <div className="titleHead">{props.title}</div>
              <a href="#" className="cart">
                <svg
                  xmlnsXlink="http://www.w3.org/1999/xlink"
                  width="36"
                  height="24"
                >
                  <defs>
                    <path
                      id="cart-16.554a2"
                      d="M5.406 6.562l1.056 7.924H18.44l1.585-7.924H5.406zm-.214-1.6H21a.8.8 0 01.784.957l-1.904 9.524a.8.8 0 01-.785.643H5.762a.8.8 0 01-.793-.695L3.157 1.8H1A.8.8 0 111 .2h2.857a.8.8 0 01.793.694l.542 4.068zM6.5 21a1.5 1.5 0 110-3 1.5 1.5 0 010 3zm12 0a1.5 1.5 0 110-3 1.5 1.5 0 010 3z"
                    ></path>
                  </defs>
                  <g
                    fill="#FFFFFF"
                    fillRule="evenodd"
                    transform="translate(6 2)"
                  >
                    <mask id="cart-16.554a2-b" fill="#fff">
                      <use xlinkHref="#cart-16.554a2"></use>
                    </mask>
                    <use fill="#FFFFFF" xlinkHref="#cart-16.554a2"></use>
                    <g fill="#FFFFFF" mask="url(#cart-16.554a2-b)">
                      <path d="M0-2h24v24H0z"></path>
                    </g>
                  </g>
                </svg>
              </a>
            </div>
          </div>
        </div>
      </header>
    </HeaderV2Wrapper>
  );
};

HeaderV2.propTypes = {};

export default HeaderV2;
