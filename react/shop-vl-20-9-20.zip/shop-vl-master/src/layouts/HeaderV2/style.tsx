import styled from "styled-components";
import { themeGet } from "@styled-system/theme-get";

const HeaderV2Wrapper = styled.div`
  .header-main {
    position: fixed;
    max-width: 768px;
    z-index: 10;
    top: 0px;
    left: 0px;
    right: 0px;
    background-color: #1ba8ff;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    padding: 0px 8px;
    height: 56px;
    margin: 0 auto;
    justify-content: space-between;
    &.noCart {
      justify-content: start;
    }
    &.header4 {
      background: #7c57da;
    }
  }
  .btn-back {
    min-width: 40px;
    height: 40px;
    padding: 0px;
    border: 0px;
    background: 0px center;
    outline: 0px;
    color: rgb(255, 255, 255);
    display: flex;
    -webkit-box-pack: center;
    justify-content: center;
    -webkit-box-align: center;
    align-items: center;
    z-index: 2;
    cursor: pointer;
  }
  .cart {
    background: 0px center;
    width: 44px;
    height: 40px;
    border: 0px;
    margin: 0px;
    color: rgb(255, 255, 255);
    position: relative;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
  }
  .titleHead {
    color: rgb(255, 255, 255);
    font-size: 17px;
    text-align: center;
  }
  @media (min-width: 768px) {
    .header-main {
      &.header4 {
        background: #7c57da;
        border-left: 1px solid #efefef;
        border-right: 1px solid #efefef;
      }
    }
  }
`;

export default HeaderV2Wrapper;
