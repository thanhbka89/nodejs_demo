export const siteMetadata = {
  title: `PickBazar`,
  author: {
    name: `RedQ, Inc`,
    summary: ``,
  },
  description: ``,
  siteUrl: ``,
  social: {
    twitter: ``,
  },
};
