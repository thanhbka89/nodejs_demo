
export function gerDiscountPrice(price, discount) {
  return price * (100 - discount) * 0.01;
}

function numberWithCommas(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

export function getMoneyFormat(money = 0) {
  return `${numberWithCommas(money)} VNĐ`;
}

export function getPointFormat(money) {
  return `${numberWithCommas(money)}`;
}

export function getDiscountMoneyFormat(price, discount) {
  return `${numberWithCommas(gerDiscountPrice(price, discount))} VNĐ`;
}