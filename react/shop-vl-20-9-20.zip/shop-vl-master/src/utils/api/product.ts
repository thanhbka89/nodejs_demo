import axios from 'utils/api/axios';
const defaultParam = '?filter[active]=true&filter[pending]=false';

const productFetcher = (url, page) => axios.get(url, { params: { page } }).then((res) => res.data);
const url = process.env.NEXT_PUBLIC_REST_API_ENDPOINT;
export async function getAllProducts() {
  const products = await axios.get('/public/product' + defaultParam);
  return await products.data;
}
export async function getProductBySlug(slug) {
  console.log('getProductBySlug', slug)
  const products = await axios.get('/public/product/' + slug)
    .then((res) =>
      res.data
    );
  // console.log(products)
  return products.data;
}
