import Cookies from 'js-cookie';
import axios from 'axios';
// Add a request interceptor
axios.interceptors.request.use(
  config => {
    const token = Cookies.get('token');
    if (token) {
      config.headers['Authorization'] = 'Bear ' + token;
    }
    // config.headers['Content-Type'] = 'application/json';
    return config;
  },
  error => {
    Promise.reject(error);
  });

axios.interceptors.response.use((response) => {
  return response;
},
  function (error) {
    const originalRequest = error.config;
    // console.log('interceptors.response', error.response.status);
    if (error.response.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      return axios.post('/auth/refresh-token',
        {
          refreshToken: Cookies.get('refresh_token')
        })
        .then(res => {
          // console.log('res', res.status, res.data);
          if (res.status === 201 || res.status === 200) {
            // 1) put token to LocalStorage
            const { token } = res.data;
            Cookies.set('token', token || '', { expires: 900 });
            // 2) Change Authorization header
            axios.defaults.headers.common['Authorization'] = 'Bear ' + token;

            // 3) return originalRequest object with Axios.
            return axios(originalRequest);
          }
        })
        .catch((err) => {
          console.log('err', err);
        });
    }
  });
axios.defaults.baseURL = process.env.NEXT_PUBLIC_REST_API_ENDPOINT;
axios.defaults.headers.post['Content-Type'] = 'application/json';

export default axios;
